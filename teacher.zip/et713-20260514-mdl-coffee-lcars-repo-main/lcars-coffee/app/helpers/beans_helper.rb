module BeansHelper
end
