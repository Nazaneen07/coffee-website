# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_05_14_220619) do
  create_table "beans", force: :cascade do |t|
    t.string "bean_type"
    t.datetime "created_at", null: false
    t.text "description"
    t.decimal "price"
    t.string "product_name"
    t.integer "quantity"
    t.integer "supplier_id", null: false
    t.datetime "updated_at", null: false
    t.index ["supplier_id"], name: "index_beans_on_supplier_id"
  end

  create_table "suppliers", force: :cascade do |t|
    t.string "address"
    t.string "city"
    t.datetime "created_at", null: false
    t.string "email"
    t.string "name"
    t.string "phone"
    t.string "state"
    t.datetime "updated_at", null: false
  end

  add_foreign_key "beans", "suppliers"
end
